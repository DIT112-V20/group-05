package com.example.uidesign

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import kotlinx.android.synthetic.main.activity_manual2.*


class ManualActivity2 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manual2)


        val go_back2 = findViewById(R.id.back2) as ImageButton

        go_back2.setOnClickListener {

            val intent = Intent(this, MenuActivity::class.java)
            startActivity(intent)
        }


        var gear1background: Int = 2;
        var gear2background: Int = 2;
        var gear3background: Int = 2;


        var button_change = findViewById(R.id.gear1) as Button;
        var button_change2 = findViewById(R.id.gear2) as Button;
        var button_change3 = findViewById(R.id.gear3) as Button;


        button_change.setOnClickListener {
            if (gear1background == 2) {

                button_change.setBackgroundResource(R.drawable.chosengear);
                gear1background = 1;
                if (gear2background == 1 || gear3background == 1) {
                    button_change3.setBackgroundResource(R.drawable.gears);
                    gear3background = 2;
                    button_change2.setBackgroundResource(R.drawable.gears);
                    gear2background = 2;

                }
            }
        }


            button_change2.setOnClickListener {
                if (gear2background == 2) {
                    button_change2.setBackgroundResource(R.drawable.chosengear);
                    gear2background = 1;
                    if (gear1background == 1 || gear3background == 1) {
                        button_change.setBackgroundResource(R.drawable.gears);
                        gear1background = 2;
                        button_change3.setBackgroundResource(R.drawable.gears);
                        gear3background = 2;

                    }
                }



                button_change3.setOnClickListener {
                    if (gear3background == 2) {
                        button_change3.setBackgroundResource(R.drawable.chosengear);
                        gear3background = 1;
                        if (gear2background == 1 || gear1background == 1)
                            button_change2.setBackgroundResource(R.drawable.gears);
                        gear2background = 2;
                        button_change.setBackgroundResource(R.drawable.gears);
                        gear1background = 2;

                    }
                }


            }
        }

    }
